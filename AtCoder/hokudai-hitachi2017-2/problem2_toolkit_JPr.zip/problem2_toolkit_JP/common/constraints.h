// G
const int MIN_V = 2;
const int MAX_V = 500;

const int MIN_E = 1;
const int MAX_E = 20000;

// G emb (square)
const int MIN_N = 2;
const int MAX_N = 60;
